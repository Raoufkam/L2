#include <stdio.h>
#include <stdbool.h>
#include "couche_transport.h"
#include "services_reseau.h"

/* ************************************** */
/* Fonctions utilitaires couche transport */
/* ************************************** */

/**
 * 		Fonction pour génerer les contrôles d'un paquet
 **/
 
uint8_t generer_controle (paquet_t p) {
	uint8_t var = (p.type ^ p.num_seq ^ p.lg_info);
		for (int i=0; i < p.lg_info; i+=1) {
			var = var ^ p.info[i];	
	}
	return var;
}

/**
 * 		Fonction qui fait la vérification des contrôles 
 */
 
bool verifier_controle (paquet_t p){
	if (generer_controle (p) == p.somme_ctrl) {
		return true;
	}
	else {
		return false;
	}
}
/* ======================================================================= */
/* =================== Fenêtre d'anticipation ============================ */
/* ======================================================================= */

/*--------------------------------------*/
/* Fonction d'inclusion dans la fenetre */
/*--------------------------------------*/
int dans_fenetre(unsigned int inf, unsigned int pointeur, int taille) {

    unsigned int sup = (inf+taille-1) % SEQ_NUM_SIZE;

    return
        /* inf <= pointeur <= sup */
        ( inf <= sup && pointeur >= inf && pointeur <= sup ) ||
        /* sup < inf <= pointeur */
        ( sup < inf && pointeur >= inf) ||
        /* pointeur <= sup < inf */
        ( sup < inf && pointeur <= sup);
}
