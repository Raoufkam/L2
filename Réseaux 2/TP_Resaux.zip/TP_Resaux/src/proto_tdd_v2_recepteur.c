/*************************************************************
* proto_tdd_v2 -  RECEPTEUR                                   *
*                                  							 *
*                                                            *
* Protocole v2: transfert de données avec contrôle de flux et
* retrensmission  " Stop-and-Wait "                          *
*                 											 *
* KAMICHE Mohamed- Univ. de Toulouse III - Paul Sabatier     *
**************************************************************/

#include <stdio.h>
#include "application.h"
#include "couche_transport.h"
#include "services_reseau.h"

/* =============================== */
/* Programme principal - RECEPTEUR */
/* =============================== */

int main(int argc, char* argv[]) {

    unsigned char message[MAX_INFO]; /* message pour l'application */
    paquet_t pdata, pack;  /* paquet utilisé par le protocole */
    int fin = 0;      /* condition d'arrêt */
    int paquet_attendu;
    init_reseau(RECEPTION);
   
    printf("[TRP] Initialisation reseau : OK.\n");
    printf("[TRP] Debut execution protocole transport.\n");
   
    pack.type = ACK;
    paquet_attendu = 0;
   
    /* tant que le récepteur reçoit des données */
    while ( ! fin )  {
        
        de_reseau(&pdata);
        if (verifier_controle(pdata)) {
          if (pdata.num_seq == paquet_attendu) {
       
        /* extraction des donnees du paquet reçu */
            for (int i=0; i<pdata.lg_info; i++) 
                message[i] = pdata.info[i];
      
        /* remise des données à la couche application */
            fin = vers_application(message, pdata.lg_info);
            paquet_attendu = 1- paquet_attendu;
          }
          vers_reseau(&pack);
        }
    }
    printf("[TRP] Fin execution protocole transport.\n");
    return 0;
}
