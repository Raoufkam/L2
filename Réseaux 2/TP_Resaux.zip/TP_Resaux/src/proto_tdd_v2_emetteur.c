/*************************************************************
* proto_tdd_v2 -  EMETTEUR                                   *
*                                  							 *
*                                                            *
* Protocole v2: transfert de données avec contrôle de flux et
* retrensmission  " Stop-and-Wait "                          *
*                 											 *
* KAMICHE Mohamed- Univ. de Toulouse III - Paul Sabatier     *
**************************************************************/

#include <stdio.h>
#include "application.h"
#include "couche_transport.h"
#include "services_reseau.h"

/* =============================== */
/* Programme principal - EMETTEUR  */
/* =============================== */

int main(int argc, char* argv[]) {
	
    unsigned char message[MAX_INFO]; /* message de l'application */
    int taille_msg;   /* taille du message */
    paquet_t pdata, pack;  /* paquet utilisé par le protocole */
    int evt;
    int prochain_paquet;
    init_reseau(EMISSION);
    
    printf("[TRP] Initialisation reseau : OK.\n");
    printf("[TRP] Debut execution protocole transport.\n");
    
    /* lecture de donnees provenant de la couche application */
    prochain_paquet = 0;
    de_application(message, &taille_msg);
    
    /* tant que l'émetteur a des données à envoyer */
    while ( taille_msg != 0 ) {
        /* construction paquet */
        
        for (int i=0; i<taille_msg; i++) 
            pdata.info[i] = message[i];
        pdata.lg_info = taille_msg;
        pdata.num_seq = prochain_paquet;
        pdata.type = DATA;
        pdata.somme_ctrl = generer_controle(pdata);
        
        /* remise à la couche reseau */
        do {
          vers_reseau(&pdata);
          depart_temporisateur(0,10);
          evt = attendre();
        }
        
        while (evt == 0);
        /* lecture des donnees suivantes de la couche application */
        de_reseau(&pack);
        arreter_temporisateur(0);
        prochain_paquet = 1- prochain_paquet ;
        de_application(message, &taille_msg);
    }
    printf("[TRP] Fin execution protocole transfert de donnees (TDD).\n");
    return 0;
}
