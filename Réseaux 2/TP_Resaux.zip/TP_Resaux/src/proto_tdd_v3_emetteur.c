/*************************************************************
* proto_tdd_v3 -  EMETTEUR                                   *
*                                  							 *
*                                                            *
* Protocole v3: transfert de données avec retrensmission     *
* 						" GoBackN" 							 *
* 									                         *
*                 											 *
* KAMICHE Mohamed- Univ. de Toulouse III - Paul Sabatier     *
**************************************************************/

#include <stdio.h>
#include "application.h"
#include "couche_transport.h"
#include "services_reseau.h"

/* =============================== */
/* Programme principal - EMETTEUR  */
/* =============================== */


int main(int argc, char *argv[]) {
	
    unsigned char message[MAX_INFO]; /* message de l'application */
    int taille_msg =1;                 /* taille du message */
    paquet_t p_controle;             /* paquet de controle */
    int code_controle;
    int taille_fenetre =4;
    int borne_inf = 0;
    int curseur =0;
    int n_tempo = 0;
    int duree_tempo = 100;
    paquet_t tab[SEQ_NUM_SIZE];
    int cmpt=0;
    init_reseau(EMISSION);
    printf("[TRP] Initialisation reseau : OK.\n");
    printf("[TRP] Debut execution protocole transport.\n");

    do {  /* tant que l'émetteur a des données à envoyer */
        if (taille_msg >0 && dans_fenetre(borne_inf, curseur, taille_fenetre && taille_msg >0))  {   /* lecture de donnees provenant de la couche application */
            de_application(message, &taille_msg);     /* construction paquet */
            for (int i = 0; i < taille_msg; i++)  {
                tab[curseur].info[i] = message[i];
            }
            printf ("envoi paquet curseur %d\n", curseur);
            cmpt=0;
            tab[curseur].num_seq = curseur;
            tab[curseur].lg_info = taille_msg;
            tab[curseur].type = DATA;
            tab[curseur].somme_ctrl = generer_controle(tab[curseur]);
            vers_reseau(&tab[curseur]);
            if (borne_inf == curseur){
                depart_temporisateur(n_tempo, duree_tempo);
            }
            curseur = (curseur +1) %8;
        }
        else {
            code_controle = attendre();
            if (code_controle == PAQUET_RECU) {
                de_reseau(&p_controle);
                printf ("reception paquet %d\n", p_controle.num_seq);
                if (verifier_controle(p_controle) && dans_fenetre(borne_inf, p_controle.num_seq, taille_fenetre)) {
                    // on décale la fenetre
                    borne_inf = (p_controle.num_seq +1) %8 ;
                    printf ("borne inf %d\n", borne_inf);
                    arreter_temporisateur(0);
                    if (borne_inf != curseur) { // il reste des paquets non acquittés, on relance le timer
                        depart_temporisateur(n_tempo, duree_tempo);
                    }
                }
            }
            else {      // Timeout: go-back-n
            	cmpt+=1;
            	if (cmpt==50) {
            		return 1;
            	}
                int i = borne_inf;
                depart_temporisateur(n_tempo, duree_tempo);
                while (i != curseur)  {
                    vers_reseau(&tab[i]);
                    i= (i+1) %8 ;
                    printf ("transmission i %d\n", i);
                }
            }
        }
    }
    while (taille_msg != 0 || borne_inf != curseur);
    printf("[TRP] Fin execution protocole transfert de donnees (TDD).\n");
    return 0;
}
